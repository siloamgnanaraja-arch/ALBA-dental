Put your image files in this folder using these exact names:

  logo.png            -> clinic logo (already included)
  dr-peter.jpg        -> photo of Dr. Peter S, MDS (Chief Dentist)

Once the file is here with this name, it will automatically appear
on the website in place of the "ADD DOCTOR IMAGE" placeholder box.
No code changes needed.

Tips:
- dr-peter.jpg works best as a square, front-facing photo
  (e.g. 400x400px or larger).
- If your file is a different format (e.g. .jpeg, .webp, .png),
  either rename it to match the name above, or open index.html and
  update the matching src="images/..." path.
